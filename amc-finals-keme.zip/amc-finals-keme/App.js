import React, { useState, useRef } from 'react';
import { Text, View, StyleSheet, TouchableOpacity, ScrollView, Image, Linking, TextInput, Alert, useWindowDimensions, FlatList  } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

const handlePress = () => {
  Linking.openURL("https://www.facebook.com");
}


const images = [
  { id: '1', image: require('./assets/ball.jpg') },
  { id: '2', image: require('./assets/net.jpg') },
  { id: '3', image: require('./assets/jnee.jpg') },
  { id: '4', image: require('./assets/shoes.jpg') },
  { id: '5', image: require('./assets/sh.jpg') },
  // Add more images as needed
];

const prod = [
  { id: '1', image: require('./assets/jersey.jpg') },
  { id: '2', image: require('./assets/bag.jpg') },
  { id: '3', image: require('./assets/short.jpg') },
  { id: '4', image: require('./assets/tape.jpg') },
  { id: '5', image: require('./assets/band.jpg') },
  // Add more images as needed
];

const test = [
  { id: '1', image: require('./assets/1.jpg'), name: 'Brix' },
  { id: '2', image: require('./assets/2.jpg'), name: 'Marco' },
  { id: '3', image: require('./assets/3.jpg'), name: 'Ang' },
  { id: '4', image: require('./assets/4.jpg'), name: 'Ganda' },
  { id: '5', image: require('./assets/5.jpg'), name: 'Sobrang Ganda' },
  // Add more images as needed
];

export default function App() {
  const [appointDate, setAppointDate] = useState("");
  const [appointTime, setAppointTime] = useState("");

  const onAppoint = () => {
      Alert.alert("Congratulation!", "You have been set an appointment", [{ text: 'OK' }]);
  };

  const [activeIndex, setActiveIndex] = useState(0);
  const { width } = useWindowDimensions(); // This hook provides the dimensions of the screen

  const onViewRef = useRef(({ viewableItems }) => {
    if (viewableItems.length > 0) {
      setActiveIndex(viewableItems[0].index);
    }
  });

  const viewConfigRef = useRef({ viewAreaCoveragePercentThreshold: 50 });

  return (
    <ScrollView style={{backgroundColor: '#1c1c1c'}}>
      <View style={{position: 'absolute'}}>
        <Image source={require('./assets/1420394432.jpg')} style={styles.cover}/>
      </View>
      <View style = {{flexDirection: 'row'}}>
        <Image source={require('./assets/brix.jpg')} style={styles.profile}/>
        <View styles = {{flexDirection: 'row'}}>
          <Text style = {styles.header}>Brix Marco Ang</Text>
          <Text style = {styles.paragraph}>Programmer</Text>
        </View>
      </View>
      <View style = {{flexDirection: 'row'}}> 
      </View>
      <Text style = {styles.paragraph2}>Hello, I'm Brix Marco Ang, a skilled programmer to take a challenging and managerial role in the field of Computer Programming and implement the expertise and experience gained in this field to develop complex projects with efficiency and quality.</Text>
      <View style={{flexDirection: 'row'}}>
        <View style={styles.container}>
            <View style={{flexDirection:'row'}}>
              <Image source={require('./assets/mail.png')} style={styles.image3}/>
              <Text style={{fontSize: 15, fontWeight: 'bold', marginTop: 15, marginLeft: 5}}>Email Address</Text>
            </View>
          <Text style={styles.paragraph3}>angbrixmarco@gmail.com</Text>
        </View>
        <View style={styles.container}>
          <View style = {{flexDirection: 'row'}}>
            <Image source = {require('./assets/phone.png')} style={styles.image3}/>
            <Text style={{fontSize: 15, fontWeight: 'bold', marginTop: 15, marginLeft: 5}}>Mobile Number</Text>
          </View>
          <Text style={styles.paragraph3}>09915077974</Text>
        </View>
      </View>
      <View style={{flexDirection: 'row', marginTop: 15}}>
        <View style={styles.container}>
          <View style = {{flexDirection: 'row'}}>
            <Image source={require('./assets/cake.png')} style={styles.image3}/>
            <Text style={{fontSize: 15, fontWeight: 'bold', marginTop: 15, marginLeft: 10}}>Date of Birth</Text>
          </View>
          <Text style={styles.paragraph3}>February 23, 2003</Text>
        </View>
        <View style={styles.container}>
          <View style={{flexDirection: 'row'}}>
            <Image source={require('./assets/gps.png')} style={styles.image3}/>
            <Text style = {{fontSize: 15, fontWeight: 'bold', marginTop: 15, marginLeft: 15}}>Location</Text>
          </View>
          <Text style={styles.paragraph3}>Blk 37 Lot 5 Gulayan Catmon Malabon City</Text>
        </View>
      </View>
      <View style={styles.center}>
        <View style={styles.container2}>
          <Text style={{textAlign: 'center', fontWeight: 'bold', color: 'white', paddingTop: 15}}>Make an Appointment</Text>
        </View>
      </View>
      <View style={styles.center}>
        <View style={styles.container3}> 
          <TextInput
            value={appointDate}
            placeholder="   Enter a Date"
            onChangeText={setAppointDate}
            style = {styles.input}
            placeholderTextColor="gray"
          />
          <TextInput
            value={appointTime}
            placeholder="   Enter a Time"
            onChangeText={setAppointTime}
            style = {styles.input}
            placeholderTextColor="gray"
          />
          <View style={styles.center}>
            <TouchableOpacity onPress={onAppoint} style={styles.button}>
              <Text style={{textAlign: 'center', fontWeight: 'bold', paddingTop: 5}}>Submit</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <View style={styles.center}>
        <View style={styles.container2}>
          <Text style={{textAlign: 'center', fontWeight: 'bold', color: 'white', paddingTop: 15}}>Our Services</Text>
        </View>
      </View>
      <Text style={styles.header2}>Graphic Design</Text>
      <Text style={styles.paragraph4}>Graphic design is a dynamic and creative field that involves visual communication through the use of typography, imagery, and layout. As a graphic designer, Brix Marco Ang harnesses these elements to craft compelling and memorable designs across various mediums. With over a decade of experience, Ang has become known for his bold and innovative approach, blending minimalism with vibrant colors and typography to create visually striking compositions. His work spans branding campaigns, editorial layouts, and digital interfaces, showcasing his versatility and talent in translating ideas into impactful visuals. Beyond his design projects, Ang is dedicated to mentoring and inspiring emerging designers, sharing his expertise through workshops and online tutorials. In the ever-evolving landscape of graphic design, Brix Marco Ang continues to push boundaries and set new standards of creativity and excellence. </Text>
      <Text style={styles.header2}>Programmer</Text>
      <Text style={styles.paragraph4}>A dedicated and versatile programmer with years of experience in developing robust and scalable software solutions. Proficient in multiple programming languages including java, with a strong foundation in software engineering. Known for a detail-oriented approach to problem-solving and a passion for staying abreast of emerging technologies. A collaborative team player with a proven track record of delivering high-quality projects on time and within budget. Seeking opportunities to leverage technical skills and contribute to innovative projects in a dynamic work environment.</Text>
      <View style={styles.center}>
        <View style={styles.container2}>
          <Text style={{textAlign: 'center', fontWeight: 'bold', color: 'white', paddingTop: 15}}>Gallery</Text>
        </View>
      </View>
     <View style={{marginTop: 15}}>
      <FlatList
        data={images}
        renderItem={({ item }) => (
          <Image source={item.image} style={{ width, height: 240 }} />
        )}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScrollToIndexFailed={info => {
          console.log("Scroll to index failed:", info);
        }}
        onViewableItemsChanged={onViewRef.current}
        viewabilityConfig={viewConfigRef.current}
        keyExtractor={item => item.id}
        
      />
      <View style={styles.pagination}>
        {images.map((_, index) => (
          <View
            key={index}
            style={[styles.dot, index === activeIndex ? styles.activeDot : null]}
          />
        ))}
      </View>
    </View>
    <View style={styles.center}>
        <View style={styles.container2}>
          <Text style={{textAlign: 'center', fontWeight: 'bold', color: 'white', paddingTop: 15}}>Products</Text>
        </View>
      </View>
      <View style={{marginTop: 15}}>
      <FlatList
        data={prod}
        renderItem={({ item }) => (
            <View style = {styles.container4}>
              <Text style = {{marginTop: 15, marginLeft: 15, fontSize: 20, fontWeight: 'bold'}}>Products</Text>
              <View style = {styles.center}>

                <Image source={item.image} style={{ width: 310, height: 170, borderRadius: 15 }} />
              </View>
              <Text style = {{marginTop: 15, marginLeft: 15, marginBottom: 15, fontSize: 20,}}></Text>
            </View>
        )}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScrollToIndexFailed={info => {
          console.log("Scroll to index failed:", info);
        }}
        onViewableItemsChanged={onViewRef.current}
        viewabilityConfig={viewConfigRef.current}
        keyExtractor={item => item.id}
        
      />
      <View style={styles.pagination}>
        {images.map((_, index) => (
          <View
            key={index}
            style={[styles.dot, index === activeIndex ? styles.activeDot : null]}
          />
        ))}
      </View>
    </View>
    <View style={styles.center}>
        <View style={styles.container2}>
          <Text style={{textAlign: 'center', fontWeight: 'bold', color: 'white', paddingTop: 15}}>Testimonial</Text>
        </View>
      </View>
      <View style={{marginTop: 15}}>
      <FlatList
        data={test}
        renderItem={({ item }) => (
            <View style = {styles.container4}>
              <Text style = {{marginTop: 15, marginLeft: 15, fontSize: 20, fontWeight: 'bold'}}>{item.name}</Text>
              <View style = {styles.center}>
              <TouchableOpacity onPress={handlePress}>
                <Image source={item.image} style={{ width: 200, height: 200, borderRadius: 101, borderColor: '#C9BEAD', borderWidth: 5 }} />
                </TouchableOpacity>
              </View>
              <Text style = {{marginTop: 15, marginLeft: 15, marginBottom: 15, fontSize: 20,}}></Text>
            </View>
        )}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScrollToIndexFailed={info => {
          console.log("Scroll to index failed:", info);
        }}
        onViewableItemsChanged={onViewRef.current}
        viewabilityConfig={viewConfigRef.current}
        keyExtractor={item => item.id}
        
      />
      <View style={styles.pagination}>
        {images.map((_, index) => (
          <View
            key={index}
            style={[styles.dot, index === activeIndex ? styles.activeDot : null]}
          />
        ))}
      </View>
    </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },

  cover: {
    height: 200, 
    width: 400,
  },

  profile: {
    height: 150,
    width: 150,
    borderRadius: 100,
    borderWidth: 5,
    borderColor: '#BEB7B7',
    marginLeft: 15,
    marginTop: 110
  },

  header: {
    marginTop: 200,
    marginLeft: 7,
    color: 'white',
    fontWeight: 'bold',
    fontSize: 17
  },

  paragraph: {
    marginTop: 5,
    marginLeft: 7,
    color: 'white',
    fontWeight: 'bold',
    fontSize: 15
  },

  image: {
    height: 50,
    width: 50,
    marginLeft: 170
  },

  image2: {
    height: 50,
    width: 50,
    marginLeft: 15,
  },

  paragraph2: {
    textAlign: 'justify',
    fontSize: 15,
    color: 'white',
    padding: 15,
  },

  container: {
    height: 100,
    width: 175,
    marginLeft: 15,
    backgroundColor: '#C9BEAD',
    borderRadius: 15,
  },

  image3: {
    height: 50,
    width: 50,
  },

  paragraph3: {
    fontSize: 13,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'white',
    marginTop: 5
  },

  container2: {
    height: 50,
    width: 200,
    backgroundColor: '#C9BEAD',
    borderRadius: 10,
    marginTop: 15,
  },

  container3: {
    height: 250,
    width: 330,
    backgroundColor: '#C9BEAD',
    marginTop: 15,
    borderRadius: 10
  },

  input: {
    height: 50,
    width: 265,
    backgroundColor: 'white',
    marginLeft: 30,
    marginRight: 30,
    marginTop: 30
  },

  button: {
    height: 30,
    width: 100,
    backgroundColor: 'white',
    borderRadius: 10
  },

  header2: {
    textAlign: 'center',
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginTop: 15
  },

  paragraph4: {
    textAlign:'justify',
    paddingLeft: 15,
    paddingRight: 15,
    fontSize: 15,
    color: 'white',
    marginTop: 15
  },

  pagination: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
  },
  dot: {
    height: 10,
    width: 10,
    borderRadius: 5,
    backgroundColor: 'gray',
    margin: 8,
  },
  activeDot: {
    backgroundColor: 'black',
  },

  container4: {
    height: 330,
    width: 360,
    backgroundColor: 'white',
    marginLeft: 15,
    marginRight: 15,
    borderRadius: 10
  },
  
});